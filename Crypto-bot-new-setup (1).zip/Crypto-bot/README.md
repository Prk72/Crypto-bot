# Crypto-bot setup

GitHub secrets (Settings -> Secrets and variables -> Actions):
TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, GEMINI_API_KEY, LINK_HUB_URL (aapka Telegram link)
